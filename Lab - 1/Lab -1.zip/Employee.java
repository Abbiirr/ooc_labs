public class Employee {
	String name;
	int age;
	int baseSalary;

	public void showEmployeeInfo() {
		System.out.println("Name: " + this.name + " -- Age: " + this.age + " -- Base Salary: " + this.baseSalary);
	}
	
}