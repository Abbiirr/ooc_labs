public class SalesAssociate extends Employee {
	
	float bonus;
	float totalSalary;

	public SalesAssociate(String name, int age, int salary)
	{
		this.name = name;
		this.age = age;
		this.baseSalary = salary;

		System.out.println("----Sales Associate has been added!----");
		System.out.println("Name: "+ this.name + " -- Age: "+ this.age + " -- Base Salary: " + this.baseSalary + " -- Bonus: " + this.bonus + " -- Total Salary: " + this.totalSalary );
	}

	public void sellProduct(int id, int qty, Store store) {
		System.out.println(store.inventory.get(id).getID());
		for(int i=0; i < store.inventory.size() ; i++)
		{
			//System.out.println(store.inventory.get(i).getName());
			//System.out.println(store.inventory.get(i).getID());
			String productName;
			float saleBonus;

			if(store.inventory.get(i).getID() == id)
			{
				//System.out.println("made it");
				productName = store.inventory.get(i).getName();
				saleBonus = store.inventory.get(i).sell(qty);

				if(saleBonus > 0)
					System.out.println(productName + " has been sold and " + this.name + " has received a bonus of BDT " + saleBonus + "!"); 
				else 
					System.out.println("Not enough amount of "+ productName + ". Contact your manager!");
					
			}
		}

		//return "Product not found. Invalid product ID!\n";
	}
}