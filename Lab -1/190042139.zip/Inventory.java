public class Inventory {
	
}