public class Employee {
	String name;
	int age;
	int baseSalary;

	/*public Employee(String name, int age, int salary)
	{
		this.name = name;
		this.age = age;
		this.salary = salary;
	}*/
	
}