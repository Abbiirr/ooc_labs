import java.util.ArrayList;
public class Store {
	ArrayList<Product> inventory = new ArrayList<Product>();

	public Store() {
		System.out.println("----Store has been generated successfully!----");
	}

	public void showStoreDetails() {
		System.out.println(inventory.size());
		for(int i=0; i< inventory.size();i++)
		{
			System.out.println(inventory.get(i).getDetails());
		}
	}

	
}